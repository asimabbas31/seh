#!/usr/bin/env python
import os
os.system("docker build -f Docker.asim -t myapp:latest .")
os.system("kubectl create -f go-dep.yml")
